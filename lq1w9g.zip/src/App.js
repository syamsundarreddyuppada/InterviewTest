import { useEffect, useState } from "react";
import "./styles.css";

export default function App() {
const [meals,setMeals] = useState([]);

  let url = "https://www.themealdb.com/api/json/v1/1/search.php?f=a"
  async function fetchData(url) {
     let response = await fetch(url);
     let data = await response.json()
     setMeals(data.meals)
   }

   useEffect(()=>{
    fetchData(url)
   },[])

   console.log(meals);
   
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>
      <div className="wrapper">{meals.map((item,index)=> <div className="main_card"> <CardComponent key={index} item={item} /></div> )}</div>
    </div>
  );
}

function CardComponent(props) {
  return(
    <div className="card_body">
      <div>
        <img src={props.item.strMealThumb} width="100px" />
      </div>
      <div>
        <h5>{props.item.strMeal}</h5>
        <p>{props.item.strCategory}</p>
        <p className="info">{props.item.strInstructions}</p>
        <ul>
          <li>{props.item.strTags}</li>
        </ul>
      </div>

    </div>
  )
}
